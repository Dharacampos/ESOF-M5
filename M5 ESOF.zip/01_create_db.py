python3 01_create_db.py
dir *.db
